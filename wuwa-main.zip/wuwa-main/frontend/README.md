# React + Vite

Запуск приложения:
```
yarn install

yarn start
```

Обновление перевода:
```
yarn locale:extract

правки в переводе

yarn locale:compile
```