export const BACKEND_URL = "http://localhost:5000";

export const GOOGLE_DOC_REGLAMENT_RU =
    "https://docs.google.com/document/d/1XxY7qkYTpfLcAmxl2v3m5YUQ7xmtjpypQKLZkL70c8Q/edit?usp=drivesdk";

export const GOOGLE_DOC_REGLAMENT_EN =
    "https://docs.google.com/document/d/1H1M0rwj6aw-UV_diJg1eISEmt2dufFvJ7Ych8ozg250/edit?usp=sharing";

export const GOOGLE_REGISTRATION_FORM = "https://forms.gle/aUGLVVZhpttdYjHg8";

export const TWITCH_MIROICHII = "https://www.twitch.tv/miroichii";

export const TWITCH_MALIWAN = "https://www.twitch.tv/maliwan";
